
package com.inlamning.zoo.zo0;

public class Dog extends Animal{
    
}
